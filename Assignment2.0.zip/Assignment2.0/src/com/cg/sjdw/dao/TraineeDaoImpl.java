package com.cg.sjdw.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.sjdw.dto.Trainee;

@Repository
public class TraineeDaoImpl implements ITraineeDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		entityManager.persist(trainee);
	}

	@Override
	public void updateTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		entityManager.merge(trainee);
	}

	@Override
	public void deleteTrainee(String traineeId) {
		// TODO Auto-generated method stub
		Trainee trainee = getTrainee(traineeId);
		entityManager.remove(trainee);
	}

	@Override
	public Trainee getTrainee(String traineeId) {
		// TODO Auto-generated method stub
		Trainee trainee = entityManager.find(Trainee.class, traineeId);
		return trainee;
	}

	@Override
	public List<Trainee> getAllTrainees() {
		// TODO Auto-generated method stub
		TypedQuery<Trainee> qry = entityManager.createQuery(
				"SELECT t FROM Trainee t", Trainee.class);
		return qry.getResultList();
	}
}
