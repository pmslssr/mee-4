package com.cg.sjdw.dao;

import java.util.List;

import com.cg.sjdw.dto.Trainee;

public interface ITraineeDao {
	
	void addTrainee(Trainee trainee);

	void updateTrainee(Trainee trainee);

	void deleteTrainee(String traineeId);

	Trainee getTrainee(String traineeId);

	List<Trainee> getAllTrainees();
}
