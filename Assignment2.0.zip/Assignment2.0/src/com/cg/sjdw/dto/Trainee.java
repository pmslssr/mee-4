package com.cg.sjdw.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "trainee")
public class Trainee {
	
	@Id
	@NotNull(message = "Id is manditory")
	@NotEmpty(message = "Id is manditory")
	@Pattern(regexp = "\\d{5}", message = "Only five Characters")
	private String traineeId;

	@NotNull(message = "Name is manditory")
	@NotEmpty(message = "Name is manditory")
	@Pattern(regexp = "[a-zA-z\\s]{3,25}", message = "Must be 3 to 25 alphas only")
	private String traineeName;

	@NotNull(message = "Location is Mandatory")
	private Location traineeLocation;

	@NotNull(message = "Domain is Mandatory")
	private Domain traineeDomain;

	public String getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(String traineeId) {
		this.traineeId = traineeId;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public Location getTraineeLocation() {
		return traineeLocation;
	}

	public void setTraineeLocation(Location traineeLocation) {
		this.traineeLocation = traineeLocation;
	}

	public Domain getTraineeDomain() {
		return traineeDomain;
	}

	public void setTraineeDomain(Domain traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	public Trainee() {
		super();
		// TODO Auto-generated constructor stub
	}
}
