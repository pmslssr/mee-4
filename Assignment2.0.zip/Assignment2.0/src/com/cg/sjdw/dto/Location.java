package com.cg.sjdw.dto;

public enum Location {
	Chennai, Bangalore, Pune, Mumbai;
}
