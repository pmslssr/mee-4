package com.cg.sjdw.dto;

public enum Domain {
	JEE, DOTNET, MainFrame, PHP;
}
