package com.cg.pms.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.pms.beans.ProductBean;

@Repository
@Transactional
public class ProductDaoImpl implements IProductDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public ProductBean addProduct(ProductBean bean) {
		entityManager.persist(bean);
		entityManager.flush();
		return bean;
	}
	
	
}
