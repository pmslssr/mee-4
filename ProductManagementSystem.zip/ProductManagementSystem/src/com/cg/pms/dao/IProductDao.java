package com.cg.pms.dao;

import com.cg.pms.beans.ProductBean;

public interface IProductDao {

	public ProductBean addProduct(ProductBean bean);

	
	
}
