package com.cg.pms.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.pms.beans.AdminBean;
import com.cg.pms.beans.ProductBean;
import com.cg.pms.service.IProductService;



@Controller
public class ProductController {



	@Autowired
	private IProductService service;
	
	
	public IProductService getService() {
		return service;
	}


	public void setService(IProductService service) {
		this.service = service;
	}


	@RequestMapping("/showIndex")
	public String showHomePage() {
		return "index";
	}


	@RequestMapping("/showLogin")
	public ModelAndView showLogin() {
	
		AdminBean bean = new AdminBean();

		return new ModelAndView("login", "bean", bean);
	}
	
	
	@RequestMapping("/loginCheck")
	public ModelAndView loginCheck(	@ModelAttribute("bean") @Valid AdminBean bean,
			BindingResult result) {
		
		ModelAndView mv = null;
		if (bean.getUsername().equalsIgnoreCase("admin")&&bean.getPassword().equalsIgnoreCase("praneeth")) {
				mv = new ModelAndView("index");
			}
			 
		else{
			mv = new ModelAndView("error");
		}
		
		return mv;
	}

	
	

	
	@RequestMapping("/showAdd")
	public ModelAndView showAdd() {
	
		ProductBean bean = new ProductBean();

		return new ModelAndView("addProduct", "product", bean);
	}
	
	@RequestMapping("/addProduct")
	public ModelAndView addProduct(
			@ModelAttribute("product") @Valid ProductBean bean,
			BindingResult result) {

		ModelAndView mv = null;

		if (!result.hasErrors()) {
			bean = service.addProduct(bean);
			mv = new ModelAndView("addSuccess");
			mv.addObject("productId", bean.getProductId());
			mv.addObject("productName", bean.getProductName());
		} else {
			mv = new ModelAndView("addpProduct", "product", bean);
		}

		return mv;
	}
	
	
	
	
	
}
