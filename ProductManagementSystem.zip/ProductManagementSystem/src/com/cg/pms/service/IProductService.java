package com.cg.pms.service;

import com.cg.pms.beans.ProductBean;

public interface IProductService {

	public ProductBean addProduct(ProductBean bean);
	
}
