package com.cg.pms.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pms.beans.ProductBean;
import com.cg.pms.dao.IProductDao;

@Service
public class ProductServiceImpl implements IProductService {

	
	
	@Autowired
	IProductDao dao;

	public IProductDao getDao() {
		return dao;
	}

	public void setDao(IProductDao dao) {
		this.dao = dao;
	}
	
	@Override
	public ProductBean addProduct(ProductBean bean) {
		return dao.addProduct(bean);
	}
	
	
	
}
