package com.capgemini.onlinebanking.admin.exception;

/*********************************************************************************************
 * Class Name: BankException 
 * Description :BankException is a user Defined Exception extended from Exception super class
 *********************************************************************************************/

public class BankException extends Exception {

	private static final long serialVersionUID = 1L;

	public BankException(String message) {
		super(message);
	}

}
