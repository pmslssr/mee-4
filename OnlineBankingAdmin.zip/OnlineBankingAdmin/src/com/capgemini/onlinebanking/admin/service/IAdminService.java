package com.capgemini.onlinebanking.admin.service;

import java.util.List;

import com.capgemini.onlinebanking.admin.bean.AccountMaster;
import com.capgemini.onlinebanking.admin.bean.Customer;
import com.capgemini.onlinebanking.admin.bean.Transaction;
import com.capgemini.onlinebanking.admin.bean.UserCredentials;
import com.capgemini.onlinebanking.admin.exception.BankException;

/***************************************************************************
 * Interface Name: IAdminService
 * Description : IAdminService is a interface for the AdminServiceImpl class
 ***************************************************************************/

public interface IAdminService {

	public List<Transaction> getData(String input) throws BankException;

	public boolean add(Customer customer, AccountMaster accountMaster, UserCredentials userCredential)
			throws BankException;
}
