package com.capgemini.onlinebanking.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.onlinebanking.admin.bean.AccountMaster;
import com.capgemini.onlinebanking.admin.bean.Customer;
import com.capgemini.onlinebanking.admin.bean.Transaction;
import com.capgemini.onlinebanking.admin.bean.UserCredentials;
import com.capgemini.onlinebanking.admin.dao.IAdminDao;
import com.capgemini.onlinebanking.admin.exception.BankException;

/************************************************************************************************************
 * Class Name: AdminServiceImpl
 * Description :AdminServiceImpl implements IAdminService ,  It invokes the DAO Class methods of AdminDaoImpl
 ************************************************************************************************************/

@Service
public class AdminServiceImpl implements IAdminService {

	@Autowired
	private IAdminDao dao;

	@Override
	public List<Transaction> getData(String input) throws BankException {

		return dao.getData(input);
	}

	@Override
	public boolean add(Customer customer, AccountMaster accountMaster, UserCredentials userCredential)
			throws BankException {

		dao.add(customer, accountMaster, userCredential);
		return false;
	}

}
