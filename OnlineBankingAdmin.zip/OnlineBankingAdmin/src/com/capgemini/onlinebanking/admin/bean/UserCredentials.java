package com.capgemini.onlinebanking.admin.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

/**************************************************************************************
 * Class Name: UserCredentials
 * Description : UserCredentials Class holds the customer credentials of Online Banking
 **************************************************************************************/

@Entity(name = "User_Table")
public class UserCredentials {

	@Id
	@SequenceGenerator(name = "user_sequence", sequenceName = "user_id_seq", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_sequence")
	@Column(name = "user_id")
	private int userId;
	@Column(name = "Account_ID")
	private long accountNumber;
	@Column(name = "login_password")
	private String password;
	@Column(name = "secret_question")
	@NotEmpty
	@Pattern(regexp = "^[A-Za-z]{3,}", message = "should be alphabetic")
	private String secretQuestion;
	@Column(name = "Transaction_password")
	private String transactionPassword;
	@Column(name = "lock_status")
	private String lockStatus;

	public UserCredentials() {
		super();
	}

	public UserCredentials(long accountNumber, int userId, String password, String secretQuestion,
			String transactionPassword, String lockStatus) {
		super();
		this.accountNumber = accountNumber;
		this.userId = userId;
		this.password = password;
		this.secretQuestion = secretQuestion;
		this.transactionPassword = transactionPassword;
		this.lockStatus = lockStatus;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSecretQuestion() {
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}

	public String getTransactionPassword() {
		return transactionPassword;
	}

	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}

	public String getLockStatus() {
		return lockStatus;
	}

	public void setLockStatus(String lockStatus) {
		this.lockStatus = lockStatus;
	}

}
