package com.capgemini.onlinebanking.admin.bean;

import java.sql.Date;

import javax.persistence.*;

/*******************************************************************************************************
 * Class Name: Transaction
 * Description : Transaction class has the transaction details of every transaction done by the customer
 *******************************************************************************************************/

@Entity(name = "Transactions")
@NamedQuery(name = "retrieveTransaction", query = "select t from Transactions t where to_char(dateoftransaction,'DD-MM-YYYY') like :input")
public class Transaction {

	@Id
	@Column(name = "Transaction_ID ")
	private int transactionId;
	@Column(name = "Tran_description")
	private String transactionDescription;
	@Column(name = "DateofTransaction")
	private Date dateOfTransaction;
	@Column(name = "TransactionType")
	private char transactionType;
	@Column(name = "TranAmount")
	private long transactionAmount;
	@Column(name = "Account_No")
	private long accountNumber;

	public Transaction() {
		super();
	}

	public Transaction(String transactionDescription, char transactionType, long transactionAmount,
			long accountNumber) {
		super();
		this.transactionDescription = transactionDescription;
		this.transactionType = transactionType;
		this.transactionAmount = transactionAmount;
		this.accountNumber = accountNumber;
	}

	public Transaction(int transactionId, String transactionDescription, Date dateOfTransaction, char transactionType,
			long transactionAmount, long accountNumber) {
		super();
		this.transactionId = transactionId;
		this.transactionDescription = transactionDescription;
		this.dateOfTransaction = dateOfTransaction;
		this.transactionType = transactionType;
		this.transactionAmount = transactionAmount;
		this.accountNumber = accountNumber;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionDescription() {
		return transactionDescription;
	}

	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}

	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}

	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}

	public char getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(char transactionType) {
		this.transactionType = transactionType;
	}

	public long getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(long transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
}
