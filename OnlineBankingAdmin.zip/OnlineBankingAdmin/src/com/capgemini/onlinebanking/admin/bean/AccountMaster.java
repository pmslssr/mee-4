package com.capgemini.onlinebanking.admin.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/********************************************************************************
 * Class Name: AccountMaster 
 * Description : Account Master class holds the account details of each customer
 ********************************************************************************/
@Entity(name = "account_master")
public class AccountMaster {

	@Id
	@SequenceGenerator(name = "id_sequence", sequenceName = "account_id_seq", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "id_sequence")
	@Column(name = "Account_ID")
	private long accountNumber;
	@Column(name = "acctype")
	private String accountType;
	@Column(name = "openingbal")
	@NotNull
	@Min(3000)
	private Long openingBal;
	@Column(name = "O_date")
	private Date createdDate;

	public AccountMaster() {
		super();
	}

	public AccountMaster(long accountNumber, String accountType, Long openingBal, Date createdDate) {
		super();
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.openingBal = openingBal;
		this.createdDate = createdDate;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Long getOpeningBal() {
		return openingBal;
	}

	public void setOpeningBal(Long openingBal) {
		this.openingBal = openingBal;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
