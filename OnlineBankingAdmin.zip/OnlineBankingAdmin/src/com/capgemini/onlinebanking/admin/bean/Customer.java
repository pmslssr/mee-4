package com.capgemini.onlinebanking.admin.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

/**********************************************************************************************
 * Class Name: Customer
 * Description : Customer class has the Customer details that are given during account creation
 **********************************************************************************************/

@Entity(name = "customer")
public class Customer {

	@Id
	@Column(name = "Account_ID")
	private long accountNumber;
	@Column(name = "customer_name")
	@Pattern(regexp = "^[a-zA-z\\s]{3,}", message = "Customer Name should be Alphabetic and should be greater than 3 characters")
	private String customerName;
	@Column(name = "Email")
	@NotBlank(message = "Email cannot be empty")
	@Email(message = "Please enter valid Email ID")
	private String email;
	@Column(name = "Address")
	@Pattern(regexp = "^[A-Za-z0-9,\\s]{10,}", message = "address should be greater than 10 characters")
	private String address;
	@Pattern(regexp = "^[987]{1}[0-9]{9}$", message = "Phone Number should contain only 10 digits and should start with 7|8|9")
	@Column(name = "phonenumber")
	private String mobile;
	@Column(name = "Pancard")
	@Pattern(regexp = "^[A-Z]{5}[0-9]{4}[A-Z]{1}", message = "Invalid Pancard Number")
	private String panCard;

	public Customer() {
		super();
	}

	public Customer(long accountNumber, String customerName, String email, String address, String mobile,String panCard) {
		super();
		this.accountNumber = accountNumber;
		this.customerName = customerName;
		this.email = email;
		this.address = address;
		this.mobile = mobile;
		this.panCard = panCard;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

}
