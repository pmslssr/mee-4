package com.capgemini.onlinebanking.admin.dao;

import java.util.List;

import com.capgemini.onlinebanking.admin.bean.AccountMaster;
import com.capgemini.onlinebanking.admin.bean.Customer;
import com.capgemini.onlinebanking.admin.bean.Transaction;
import com.capgemini.onlinebanking.admin.bean.UserCredentials;
import com.capgemini.onlinebanking.admin.exception.BankException;

/***************************************************
 * Interface Name: IAdminDao
 * Description :interface for the AdminDaoImpl class
 ***************************************************/
public interface IAdminDao {

	public List<Transaction> getData(String input) throws BankException;

	public boolean add(Customer c, AccountMaster am, UserCredentials uc) throws BankException;
}
