package com.capgemini.onlinebanking.admin.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.onlinebanking.admin.bean.AccountMaster;
import com.capgemini.onlinebanking.admin.bean.Customer;
import com.capgemini.onlinebanking.admin.bean.Transaction;
import com.capgemini.onlinebanking.admin.bean.UserCredentials;
import com.capgemini.onlinebanking.admin.exception.BankException;

/**************************************************************************************************************
 * Class Name: AdminDaoImpl
 * Description :AdminDaoImpl class implements the IAdminDao ,It performs the insertion and retrieval operations
 **************************************************************************************************************/

@Repository
@Transactional
public class AdminDaoImpl implements IAdminDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Transaction> getData(String input) throws BankException {
		TypedQuery<Transaction> query = entityManager.createNamedQuery("retrieveTransaction", Transaction.class);
		query.setParameter("input", "%" + input);
		return query.getResultList();
	}

	@Override
	public boolean add(Customer customer, AccountMaster accountMaster, UserCredentials userCredential)
			throws BankException {

		accountMaster.setCreatedDate(Date.valueOf(LocalDate.now()));
		entityManager.persist(accountMaster);
		customer.setAccountNumber(accountMaster.getAccountNumber());
		entityManager.persist(customer);
		userCredential.setAccountNumber(accountMaster.getAccountNumber());
		userCredential.setLockStatus("O");
		userCredential.setPassword(
				customer.getCustomerName().substring(0, 4) + (int) Math.floor(1000 + Math.random() * 9000));
		userCredential.setTransactionPassword("" + (int) Math.floor(1000 + Math.random() * 9000));
		entityManager.persist(userCredential);
		return true;
	}

}
