package com.capgemini.onlinebanking.admin.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.onlinebanking.admin.bean.AccountMaster;
import com.capgemini.onlinebanking.admin.bean.Customer;
import com.capgemini.onlinebanking.admin.bean.Transaction;
import com.capgemini.onlinebanking.admin.bean.UserCredentials;
import com.capgemini.onlinebanking.admin.exception.BankException;
import com.capgemini.onlinebanking.admin.service.IAdminService;

/****************************************************************************************
 * Class Name: AdminController Description : Acts as a controller , Handles
 * every request and returns required result
 ****************************************************************************************/

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private IAdminService service;

	@RequestMapping("/login")
	public String getHome() {
		return "login";
	}

	/***************************************************************
	 * Method Name : validateLogin 
	 * Input Parameters : adminId,password 
	 * Return type : String Description : Validates the login credentials of the admin
	 ***************************************************************/
	@RequestMapping("/store")
	public String validateLogin(@RequestParam("adminId") String adminId, @RequestParam("pwd") String password,
			Model model) {
		if ("admin".equals(adminId) && "admin".equals(password))
			return "menu";
		else {
			model.addAttribute("errorMessage", "Admin ID or PassWord Incorrect");
			return "login";
		}

	}

	@RequestMapping(value = "accountholder")
	public String accountholder(Model m) {
		m.addAttribute("customer", new Customer());
		m.addAttribute("accountMaster", new AccountMaster());
		m.addAttribute("userCredential", new UserCredentials());
		m.addAttribute("accountTypeList", populateAccountType());
		return "accountholder";
	}

	public List<String> populateAccountType() {
		List<String> accountType = new ArrayList<String>();
		accountType.add("Savings");
		accountType.add("Current");
		return accountType;
	}

	/***********************************************************************
	 * Method Name : getAccountHolder 
	 * Input Parameters : accountMaster,userCredential,customer 
	 * Return type : String 
	 * Description : invokes the service class methods to persist the objects
	 ************************************************************************/
	@RequestMapping(value = "/account", method = RequestMethod.POST)
	public String getAccountHolder(@Valid @ModelAttribute("accountMaster") AccountMaster accountMaster,
			BindingResult bindingResult1, @Valid @ModelAttribute("userCredential") UserCredentials userCredential,
			BindingResult bindingResult2, @Valid @ModelAttribute("customer") Customer customer, BindingResult bindingResult3, Model model) {
		if (bindingResult1.hasErrors() || bindingResult2.hasErrors() || bindingResult3.hasErrors()) {

			model.addAttribute("accountTypeList", populateAccountType());
			return "accountholder";
		} else {

			try {
				service.add(customer, accountMaster, userCredential);
			} catch (BankException exception) {
				model.addAttribute("error", exception.getMessage());
				return "error";
			}
		}
		model.addAttribute("key", customer.getCustomerName());
		return "result";
	}

	@RequestMapping("/selecttransactions")
	public String getViewTransactions() {
		return "selecttransactions";
	}

	@RequestMapping("/transactioninput")
	public String getTransactionInput(@RequestParam("value") String input, Model model) {
		if ("daily".equals(input))
			model.addAttribute("inputFormat", "(dd-mm-yyyy)");
		else if ("monthly".equals(input))
			model.addAttribute("inputFormat", "(mm-yyyy)");
		else if ("yearly".equals(input))
			model.addAttribute("inputFormat", "(yyyy)");
		return "gettransactioninput";
	}

	/************************************************************************************************
	 * Method Name : getTransactions 
	 * Input Parameters : input 
	 * Return type : String 
	 * Description : retrieves the transactions done by customer by invoking the service class method
	 *************************************************************************************************/
	@RequestMapping("/transaction")
	public String getTransactions(@RequestParam("input") String input, Model model) {
		List<Transaction> transactionList = new ArrayList<Transaction>();

		try {
			transactionList = service.getData(input);
			if (transactionList.isEmpty()) {
				model.addAttribute("errorMessage", "No transactions on Given Date");
				return "gettransactioninput";
			}
			model.addAttribute("input", input);
			model.addAttribute("tList", transactionList);
		} catch (BankException exception) {
			model.addAttribute("error", exception.getMessage());
			return "error";
		}
		return "viewtransaction";
	}

	@RequestMapping("/home")
	public String getMenu() {
		return "menu";
	}

}
