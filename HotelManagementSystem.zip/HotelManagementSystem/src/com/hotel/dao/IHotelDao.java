package com.hotel.dao;

import com.hotel.beans.HotelBean;

public interface IHotelDao {


	public HotelBean getHotelDetails(String hotelName, String hotelCity);
	
	public boolean bookHotel(int hotelId);
}
