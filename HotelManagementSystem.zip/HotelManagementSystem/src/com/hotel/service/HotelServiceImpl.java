package com.hotel.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel.beans.HotelBean;
import com.hotel.dao.IHotelDao;
@Service
public class HotelServiceImpl implements IHotelService {

	
	@Autowired
	IHotelDao dao;
	
	
	
	
	public IHotelDao getDao() {
		return dao;
	}

	public void setDao(IHotelDao dao) {
		this.dao = dao;
	}

	@Override
	public HotelBean getHotelDetails(String hotelName, String hotelCity) {
		return dao.getHotelDetails(hotelName, hotelCity);
	}

	@Override
	public boolean bookHotel(int hotelId) {
		return dao.bookHotel(hotelId);
	}

}
