package com.hotel.service;

import com.hotel.beans.HotelBean;

public interface IHotelService {

public HotelBean getHotelDetails(String hotelName, String hotelCity);
	
	public boolean bookHotel(int hotelId);
}
