package com.cg.uas.service;


import java.util.List;

import javax.transaction.Transactional;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.uas.beans.ApplicationBean;
import com.cg.uas.beans.LoginBean;
import com.cg.uas.beans.ProgramsOfferedBean;
import com.cg.uas.beans.ProgramsScheduledBean;
import com.cg.uas.beans.RegistrationBean;
import com.cg.uas.dao.IUasDao;
import com.cg.uas.exception.UASException;


@Service
@Transactional
public class UasServiceImpl implements IUasService {

	@Autowired
	IUasDao dao;
	
	
	
	public IUasDao getDao() {
		return dao;
	}



	public void setDao(IUasDao dao) {
		this.dao = dao;
	}



	@Override
	public LoginBean login(String username, String password) throws UASException {
		
		return dao.login(username, password);
				
	}

	@Override
	public RegistrationBean loginUser(String username, String password) throws UASException {
		
		return dao.loginUser(username, password);
				
	}

	@Override
	public ProgramsOfferedBean addOfferedPrograms(ProgramsOfferedBean bean) throws UASException {
		return dao.addOfferedPrograms(bean);
	}



	@Override
	public List<ProgramsOfferedBean> viewAllProgramsOffered() throws UASException {
		return dao.viewAllProgramsOffered();
	}



	@Override
	public boolean deleteProgramsOffered(String programName) throws UASException {
		
		return dao.deleteProgramsOffered(programName);
	}



	@Override
	public ProgramsOfferedBean findByName(String programName) throws UASException {
		return dao.findByName(programName);
	}



	@Override
	public int modifyProgram(ProgramsOfferedBean bean) throws UASException {
		return dao.modifyProgram(bean);
	}



	@Override
	public ProgramsScheduledBean addScheduledPrograms(ProgramsScheduledBean bean) throws UASException {
		// TODO Auto-generated method stub
		return dao.addScheduledPrograms(bean);
	}



	@Override
	public List<ProgramsScheduledBean> viewAllProgramsScheduled() throws UASException {
		// TODO Auto-generated method stub
		return dao.viewAllProgramsScheduled();
	}



	@Override
	public boolean deleteProgramsScheduled(int id) throws UASException {
		// TODO Auto-generated method stub
		return dao.deleteProgramsScheduled(id);
	}



	@Override
	public List<ProgramsScheduledBean> viewCommenceTime(
			ProgramsScheduledBean bean) throws UASException {
		return dao.viewCommenceTime(bean);
	}

	@Override
	public List<ProgramsScheduledBean> viewCourse() throws UASException {
		
		return dao.viewCourse();
	}



	@Override
	public ApplicationBean addApplicant(ApplicationBean application) throws UASException {
		return dao.addApplicant(application);
	}

	@Override
	public RegistrationBean addNewUser(RegistrationBean register) throws UASException {
		return dao.addNewUser(register);
	}



	@Override
	public ApplicationBean viewStatus(int id) throws UASException {
		return dao.viewStatus(id);
	}



	@Override
	public List<ApplicationBean> getAllApplicants(String scheduledProgramID) throws UASException {
		return dao.getAllApplicants(scheduledProgramID);
	}



	@Override
	public String getStatus(String applicantId) throws UASException {
		return dao.getStatus(applicantId);
	}



	@Override
	public String changeStatus(String status,String applicantId) throws UASException {
		return dao.changeStatus(status,applicantId);
	}





}
