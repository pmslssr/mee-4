package com.cg.uas.exception;

public class UASException extends Exception{

	public UASException() {
		super();
		
	}



	public UASException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	
	}

	public UASException(String message) {
		super(message);
	
	}

	public UASException(Throwable arg0) {
		super(arg0);

	}

	
	
}
