package com.cg.uas.controller;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.uas.beans.ApplicationBean;
import com.cg.uas.beans.LoginBean;
import com.cg.uas.beans.ProgramsOfferedBean;
import com.cg.uas.beans.ProgramsScheduledBean;
import com.cg.uas.beans.RegistrationBean;
import com.cg.uas.exception.UASException;
import com.cg.uas.service.IUasService;

@Controller
@RequestMapping("/*.obj")
public class UASController {

	@Autowired
	IUasService service;

	public IUasService getService() {
		return service;
	}

	public void setService(IUasService service) {
		this.service = service;
	}

	@RequestMapping("/welcome")
	public ModelAndView showWelcomePage(HttpServletRequest request,
			HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		mv.addObject("isFirst", 14);
		mv.setViewName("welcome");
		return mv;
	}

	@RequestMapping("/register")
	public ModelAndView regUser(
			@ModelAttribute("register") RegistrationBean reg,
			BindingResult result,HttpServletRequest request,
			HttpServletResponse res) throws UASException {
		ModelAndView mv = new ModelAndView();
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		try {
			if (!result.hasErrors()) {
				RegistrationBean reg1 = service.addNewUser(reg);
				String sql = "SELECT userEmail FROM registration"; 
				PreparedStatement stmt = con.prepareStatement(sql); 
				ResultSet rs = stmt.executeQuery(); 

				boolean AlreadyExists = false; 
				while (!rs.last() || (!AlreadyExists)) 
				{ 

				rs.next(); 
				
				if (!AlreadyExists) 
				{ 

					if (reg1 != null) {
						mv.addObject("flag1", true);
						mv.addObject("isFirst", 4);
						mv.addObject("msg1", "You are registered successfully");
						mv.addObject("reg1", reg1);
					}
				//To display home page if registration is successful 
				response.sendRedirect(response.encodeRedirectURL("index.jsp")); 
				break; 
				} 

				}
				
					// mv.addObject("msg", "Your applicant Id is: ");

					/*
					 * List<ProgramsScheduledBean> list = service.viewCourse();
					 * if (list.isEmpty()) { String msg =
					 * "There are no Courses"; mv.addObject("msg", msg); } else
					 * { mv.setViewName("viewCourse"); mv.addObject("list",
					 * list);
					 */
				
			} else {
				mv.addObject("msg", "Failed to Add");
				mv.setViewName("register");
			}

		}

		catch (Exception e) {

			mv.addObject("flag", true);

			mv.setViewName("register");
		}
		return mv;
	}

	/*
	 * @RequestMapping("/register") public ModelAndView registerUser() {
	 * ModelAndView mv = new ModelAndView(); //mv.addObject("isFirst", 14);
	 * mv.setViewName("register"); return mv; }
	 */
	// Validate login credentials

	@RequestMapping("/login")
	public ModelAndView showloginpage(HttpServletRequest request,
			HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		LoginBean bean = new LoginBean();
		//mv.addObject("isFirst", 1);
		mv.addObject("bean", bean);
		mv.setViewName("login");
		return mv;
	}
	@RequestMapping("/user")
	public ModelAndView showuserpage(HttpServletRequest request,
			HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		
		mv.setViewName("userPage");
		return mv;
	}
	@RequestMapping("/loginUser")
	public ModelAndView showUserLogin(HttpServletRequest request,
			HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		RegistrationBean bean = new RegistrationBean();
		//mv.addObject("isFirst", 1);
		mv.addObject("reg", bean);
		mv.setViewName("loginUser");
		return mv;
	}
	
	@RequestMapping("/userValidate")
	public ModelAndView loginUser(@ModelAttribute("reg") RegistrationBean rbean,
			BindingResult result, HttpSession session, HttpServletResponse res) {
		ModelAndView mv = new ModelAndView();
		
		if (!result.hasErrors()) {
			try {
				res.setHeader("Cache-Control", "no-cache");
				res.setHeader("Cache-Control", "no-store");
				res.setDateHeader("Expires", 0);
				res.setHeader("Pragma", "no-cache");
				
				 RegistrationBean rbean1 = service.loginUser(rbean.getUserEmail(),
						rbean.getUserPassword());
				if (rbean1 != null) {
					
							if (rbean1.getUserPassword().equals(rbean.getUserPassword()))
							{
								mv = new ModelAndView("userPage");
							}
							else {
								String msg = "Incorrect Username or Password";
								//mv.addObject("isFirst", 9);
								mv.setViewName("loginUser");
								mv.addObject("msg", msg);
							}
					} 
				
					else {
				
					String msg = "User Doesn't Exist";
					
					mv.setViewName("loginUser");
					mv.addObject("msg", msg);
				}
			} catch (UASException e) {
				String msg = e.getMessage();
				mv.setViewName("error");
				mv.addObject("msg", msg);
			}
		}
		return mv;
	}
	
	@RequestMapping("/students")
	public ModelAndView studentList(HttpServletRequest request,
			HttpServletResponse res) throws UASException {
		ModelAndView mv = new ModelAndView();
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		List<ProgramsScheduledBean> list = service
				.viewCourse();
		
		
			if (list.isEmpty()) {
				String msg = "There are no Courses";
				mv.setViewName("adminPage");
				mv.addObject("msg", msg);
			} 
			else {
				mv.addObject("isFirst", 4);
				
				mv.addObject("list", list);
				mv.setViewName("adminPage");
			}
			
		
		
		
		return mv;
	}
	
	
	
	@RequestMapping("/loginValidate")
	public ModelAndView loginValidate(@ModelAttribute("bean") LoginBean bean,
			BindingResult result, HttpSession session, HttpServletResponse res) {
		ModelAndView mv = new ModelAndView();
		if (!result.hasErrors()) {
			try {
				res.setHeader("Cache-Control", "no-cache");
				res.setHeader("Cache-Control", "no-store");
				res.setDateHeader("Expires", 0);
				res.setHeader("Pragma", "no-cache");
				LoginBean bean1 = service.login(bean.getUsername(),
						bean.getPassword());
				
				if (bean1 != null) {
					
							
					if (bean1.getPassword().equals(bean.getPassword())) {
						if (bean1.getRole().equals("admin")) {
							session.setAttribute("login", bean);
							mv = new ModelAndView("adminPage");
						} else if (bean1.getRole().equals("mac")) {
							session.setAttribute("login", bean);
							List<ProgramsScheduledBean> list = service
									.viewCourse();
							if (list.isEmpty()) {
								String msg = "There are no Courses";
								mv.setViewName("macPage");
								mv.addObject("msg", msg);
							} else {
								mv.addObject("isFirst", 4);
								mv.setViewName("macPage");
								mv.addObject("list", list);
							}
						}
						
					} else {
						String msg = "Incorrect Username or Password";
						mv.addObject("isFirst", 9);
						mv.setViewName("login");
						mv.addObject("msg", msg);
					}
				}
				
					
					else {
				
					String msg = "User Doesn't Exist";
					mv.addObject("isFirst", 9);
					mv.setViewName("login");
					mv.addObject("msg", msg);
				}
			} catch (UASException e) {
				String msg = e.getMessage();
				mv.setViewName("error");
				mv.addObject("msg", msg);
			}
		} else {
			mv = new ModelAndView("login", "bean", bean);
			mv.addObject("isFirst", 1);
		}
		return mv;
	}

	@RequestMapping("/programsOffered")
	public ModelAndView offerPrograms(HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
	//	mv.addObject("isFirst", 4);
		mv.setViewName("adminPage");
		return mv;
	}

	// Add to Offered Programs

	@RequestMapping("/addProgramsOffered")
	public ModelAndView addOfferedPrograms(HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		ProgramsOfferedBean bean = new ProgramsOfferedBean();
		mv.addObject("bean", bean);
		mv.setViewName("addPrograms");
		return mv;

	}

	@RequestMapping("/AddToOffered")
	public ModelAndView addPrograms(
			@ModelAttribute("bean") ProgramsOfferedBean bean,
			BindingResult result,HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		if (!result.hasErrors()) {
			try {
				ProgramsOfferedBean bean1 = service.addOfferedPrograms(bean);
				if (bean1 != null) {
					mv.addObject("msg", "Added Successfully");
					mv.setViewName("addPrograms");
				} else {
					mv.addObject("msg", "Failed to Add");
					mv.setViewName("addPrograms");
				}

			} catch (Exception e) {
				mv.addObject("msg", "This program is already offered!!");
				mv.setViewName("addPrograms");
			}
		} else {
			mv = new ModelAndView("addPrograms", "bean", bean);
		}
		return mv;
	}

	// To view all the programs Offered

	@RequestMapping("/viewAllProgramsOffered")
	public ModelAndView viewAllOfferedPrograms(HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		try {
			List<ProgramsOfferedBean> list = service.viewAllProgramsOffered();
			if (!list.isEmpty())
			{
				mv.addObject("list", list);
			mv.setViewName("viewAllPrograms");
			}
			else {
				mv.addObject("msg", "No Programs are offered currently");
				mv.setViewName("viewAllPrograms");
			}
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		return mv;

	}

	// To Delete the programs offered

	@RequestMapping("/deleteProgramsOffered")
	public ModelAndView deleteOfferedPrograms(HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		try {
			List<ProgramsOfferedBean> list = service.viewAllProgramsOffered();
			if (!list.isEmpty())
				mv.addObject("list", list);
			else {
				mv.addObject("msg", "No Programs are offered currently");
				mv.setViewName("deleteProgramsOffered");
			}
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		return mv;

	}

	@RequestMapping("/delete")
	public ModelAndView delete(@RequestParam("programName") String name,HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		mv.addObject("isFirst", 6);
		try {
			if (service.deleteProgramsOffered(name)) {
				List<ProgramsOfferedBean> list = service
						.viewAllProgramsOffered();
				mv.addObject("list", list);
				mv.addObject("isFirst", 7);
				mv.addObject("msg", "Program details have been removed.");

				mv.setViewName("deleteProgramsOffered");
			} else {
				List<ProgramsOfferedBean> list = service
						.viewAllProgramsOffered();
				mv.addObject("list", list);
				mv.addObject("isFirst", 7);
				mv.addObject("msg", "Deletion Failed");
				mv.setViewName("deleteProgramsOffered");
			}
		} catch (Exception e) {
			try {
				List<ProgramsOfferedBean> list = service
						.viewAllProgramsOffered();
				mv.addObject("list", list);
				mv.addObject("isFirst", 7);
				mv.addObject("msg",
						"Cannot Delete this program since it is already scheduled!!");
				mv.setViewName("deleteProgramsOffered");
			} catch (UASException e1) {
				String msg = e.getMessage();
				mv.setViewName("error");
				mv.addObject("msg", msg);
			}
		}
		return mv;
	}

	// To Update or Modify the offered programs

	@RequestMapping("/updateProgramsOffered")
	public ModelAndView modifyOfferedPrograms(HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		try {
			List<ProgramsOfferedBean> list = service.viewAllProgramsOffered();
			if (!list.isEmpty()) {
				mv.addObject("list", list);
				mv.setViewName("modifyProgramsOffered");
			} else {
				mv.addObject("msg", "No Programs are offered currently");
				mv.setViewName("modifyProgramsOffered");
			}
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		return mv;
	}

	@RequestMapping("/modify")
	public ModelAndView modify(@RequestParam("programName") String programName,HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		try {
			ProgramsOfferedBean bean1 = service.findByName(programName);
			mv.addObject("bean", bean1);
			mv.setViewName("modifyPrograms");

		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		return mv;
	}

	@RequestMapping("/update")
	public ModelAndView modify(
			@ModelAttribute("bean") ProgramsOfferedBean bean,
			BindingResult result,HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		try {
			int count = service.modifyProgram(bean);
			if (count > 0) {
				mv.addObject("msg", "Program Updated Successfully");
				mv.setViewName("modifyPrograms");
			} else {
				mv.addObject("msg", "Updation Failed");
				mv.setViewName("modifyPrograms");
			}
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		return mv;

	}

	@RequestMapping("/programsScheduled")
	public ModelAndView schedulePrograms(HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		//mv.addObject("isFirst", 8);
		mv.setViewName("adminPage");
		return mv;

	}

	// Add the programs to scheduled List

	@RequestMapping("/addProgramsScheduled")
	public ModelAndView addscheduledPrograms(HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		ProgramsScheduledBean bean = new ProgramsScheduledBean();
		try {
			List<ProgramsOfferedBean> list = service.viewAllProgramsOffered();
			if (!list.isEmpty()) {
				mv.addObject("list", list);
				mv.setViewName("addProgramsScheduled");
				return mv;
			} else {
				mv.addObject("msg", "No Programs are offered currently");
				mv.setViewName("addProgramsScheduled");
			}
			mv.addObject("bean", bean);
			mv.setViewName("addProgramsScheduled");
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		return mv;

	}

	@RequestMapping("/AddToScheduled")
	public ModelAndView addProgramsScheduled(
			@RequestParam("programName") String programName,HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		ProgramsScheduledBean bean = new ProgramsScheduledBean();
		bean.setProgramName(programName);
		try {
			List<ProgramsOfferedBean> list = service.viewAllProgramsOffered();
			mv.addObject("isFirst", 10);
			mv.addObject("list", list);
			mv.addObject("bean", bean);
			mv.setViewName("addProgramsScheduled");
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		return mv;
	}

	@RequestMapping("/AddScheduled")
	public ModelAndView addProgramsScheduled(
			@ModelAttribute("bean") ProgramsScheduledBean bean,
			BindingResult result,HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		try {
			if (!result.hasErrors()) {
				ProgramsScheduledBean bean1 = service
						.addScheduledPrograms(bean);
				List<ProgramsOfferedBean> list = service
						.viewAllProgramsOffered();
				mv.addObject("list", list);
				if (bean1 != null) {
					mv.addObject("isFirst", 10);
					mv.addObject("flag", 11);
					mv.addObject("msg", "Added Successfully");
					mv.setViewName("addProgramsScheduled");
					return mv;
				}

				else {
					mv.addObject("list", list);
					mv.addObject("msg", "Failed to Add");
					mv.setViewName("addProgramsScheduled");
				}

			}

			else {
				List<ProgramsOfferedBean> list = service
						.viewAllProgramsOffered();
				mv = new ModelAndView("addProgramsScheduled", "bean", bean);
				mv.addObject("isFirst", 10);
				mv.addObject("list", list);
				mv.addObject("flag", 11);
			}
		} catch (Exception e) {
			try {
				List<ProgramsOfferedBean> list = service
						.viewAllProgramsOffered();
				mv.addObject("list", list);
				mv.addObject("flag", 11);
				mv.addObject("msg", "Please enter a valid program name!");
				mv.setViewName("addProgramsScheduled");
			} catch (UASException e1) {
				String msg = e.getMessage();
				mv.setViewName("error");
				mv.addObject("msg", msg);
			}
		}
		return mv;
	}

	// Delete Programs from Scheduled list

	@RequestMapping("/deleteProgramsScheduled")
	public ModelAndView deleteSchedulePrograms(HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		try {
			List<ProgramsScheduledBean> list = service
					.viewAllProgramsScheduled();
			if (!list.isEmpty())
				mv.addObject("list", list);
			else {
				mv.addObject("msg", "No Programs are scheduled currently");
				mv.setViewName("deleteProgramsScheduled");
			}
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}

		return mv;
	}

	@RequestMapping("/deleteScheduled")
	public ModelAndView deleteScheduled(@RequestParam("programId") int id,HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		mv.addObject("isFirst", 11);
		try {
			if (service.deleteProgramsScheduled(id)) {
				mv.addObject("msg",
						"Program is removed from the scheduled list!!");
				mv.setViewName("deleteProgramsScheduled");
			} else {
				mv.addObject("msg", "Deletion Failed");
				mv.setViewName("deleteProgramsScheduled");
			}
		} catch (Exception e) {
			mv.addObject("msg",
					"Cannot Delete this program since there are participants registered for it!!");
			mv.setViewName("deleteProgramsScheduled");
		}
		return mv;
	}

	// To generate reports

	@RequestMapping("/generateReports")
	public ModelAndView GenerateReports(HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
	//	mv.addObject("isFirst", 12);
		mv.setViewName("adminPage");
		return mv;

	}

	@RequestMapping("/viewCommence")
	public ModelAndView viewCommence(HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		ProgramsScheduledBean bean = new ProgramsScheduledBean();
		mv.addObject("bean", bean);
		mv.setViewName("viewCommence");
		return mv;
	}

	@RequestMapping("/viewCommenceTime")
	public ModelAndView viewCommenceTime(
			@ModelAttribute("bean") ProgramsScheduledBean bean,
			BindingResult result,HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		mv.addObject("flag", 2);
		try {
			List<ProgramsScheduledBean> list = service.viewCommenceTime(bean);
			if (!list.isEmpty()) {
				mv.addObject("list", list);
				mv.setViewName("viewCommence");
			} else {
				mv.addObject("flag", 6);
				mv.addObject("msg",
						"No Programs are Scheduled for the given dates!");
				mv.setViewName("viewCommence");
			}
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		return mv;
	}

	@RequestMapping("/AboutUs")
	public ModelAndView show(HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		mv.addObject("isFirst", 14);
		mv.setViewName("welcome");
		return mv;
	}

	@RequestMapping("/contactUs")
	public ModelAndView showContact(HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		mv.addObject("isFirst", 3);
		mv.setViewName("welcome");
		return mv;

	}

	@RequestMapping("/programList")
	public ModelAndView viewPrograms(HttpServletResponse res) throws UASException {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		List<ProgramsScheduledBean> list = service.viewCourse();
		if (list.isEmpty()) {
			String msg = "There are no Courses";
			mv.setViewName("macPage");
			mv.addObject("msg", msg);
		} else {
			mv.addObject("isFirst", 4);
			mv.setViewName("macPage");
			mv.addObject("list", list);
		}
		return mv;
	}
	@RequestMapping("/programListAdmin")
	public ModelAndView viewProgram(HttpServletRequest request,
			HttpServletResponse res) throws UASException {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		
			mv.setViewName("adminPage");
			
		
		return mv;
	}

	@RequestMapping("/view")
	public ModelAndView viewApplicantsByProgram(
			@RequestParam("scheduledProgramId") String scheduledProgramId,HttpServletResponse res)
			throws UASException {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		List<ApplicationBean> list = service
				.getAllApplicants(scheduledProgramId);
		if (!list.isEmpty()) {
			mv.addObject("list", list);
			mv.addObject("scheduledProgramId", scheduledProgramId);
			mv.addObject("flag", 1);
			mv.addObject("isFirst", 2);
			mv.setViewName("viewApplicants");
		} else {
			mv.addObject("flag", 2);
			mv.addObject("msg", "No Applicant is Registered for this Program");
			mv.setViewName("viewApplicants");
		}

		return mv;
	}
	@RequestMapping("/viewAdmin")
	public ModelAndView viewApplicants(
			@RequestParam("scheduledProgramId") String scheduledProgramId,HttpServletResponse res)
			throws UASException {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		List<ApplicationBean> list = service
				.getAllApplicants(scheduledProgramId);
		if (!list.isEmpty()) {
			mv.addObject("list", list);
			mv.addObject("scheduledProgramId", scheduledProgramId);
			mv.addObject("flag", 1);
			mv.addObject("isFirst", 1);
			mv.setViewName("viewApplicants");
		} else {
			mv.addObject("flag", 2);
			mv.addObject("msg", "No Applicant is Registered for this Program");
			mv.setViewName("viewApplicants");
		}

		return mv;
	}
	@RequestMapping("/status")
	public ModelAndView viewStatus(
			@RequestParam("applicationId") String applicantId,
			@RequestParam("scheduledProgramId") String scheduledProgramId,HttpServletResponse res)
			throws UASException {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		String status = service.getStatus(applicantId);
		mv.addObject("status", status);
		if (status.equals("Waiting")) {
			mv.addObject("flag", 6);
			mv.addObject("applicationId", applicantId);
			mv.addObject("scheduledProgramId", scheduledProgramId);
			mv.addObject("accepted", "accepted");
			mv.addObject("rejected", "rejected");
			mv.addObject("isFirst", 2);
			mv.setViewName("changeStatus");
		} else {
			mv.addObject("applicationId", applicantId);
			mv.addObject("scheduledProgramId", scheduledProgramId);
			mv.addObject("flag", 5);
			mv.addObject("msg", "Status Cannot be Changed");
			mv.addObject("isFirst", 2);
			mv.setViewName("changeStatus");
		}

		return mv;
	}
	@RequestMapping("/statusAdmin")
	public ModelAndView viewStatusAdmin(
			@RequestParam("applicationId") String applicantId,
			@RequestParam("scheduledProgramId") String scheduledProgramId,HttpServletResponse res)
			throws UASException {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		String status = service.getStatus(applicantId);
		mv.addObject("status", status);
		if (status.equals("Waiting")) {
			mv.addObject("flag", 6);
			mv.addObject("applicationId", applicantId);
			mv.addObject("scheduledProgramId", scheduledProgramId);
			mv.addObject("accepted", "accepted");
			mv.addObject("rejected", "rejected");
			mv.addObject("isFirst", 1);
			mv.setViewName("changeStatus");
		} else {
			mv.addObject("applicationId", applicantId);
			mv.addObject("scheduledProgramId", scheduledProgramId);
			mv.addObject("flag", 5);
			mv.addObject("isFirst", 1);
			mv.addObject("msg", "Status Cannot be Changed");
			mv.setViewName("changeStatus");
		}

		return mv;
	}

	@RequestMapping("/changeStatus")
	public ModelAndView changeStatus(@RequestParam("status") String status,
			@RequestParam("applicationId") String applicantId,
			@RequestParam("scheduledProgramId") String scheduledProgramId,HttpServletResponse res)
			throws UASException {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();

		String newStatus = service.changeStatus(status, applicantId);
		mv.addObject("applicationId", applicantId);
		mv.addObject("scheduledProgramId", scheduledProgramId);
		if (newStatus.equals("rejected")) {
			mv.addObject("flag", 5);
			mv.addObject("msg", "Application has been Rejected");
			mv.setViewName("changeStatus");
		} else {
			mv.addObject("flag", 5);
			mv.addObject("msg", "Application has been Accepted");
			mv.setViewName("changeStatus");
		}
		return mv;
	}

	@RequestMapping("/viewCourse")
	public ModelAndView showabout(HttpServletResponse res) throws UASException {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		mv.addObject("isFirst", 4);
		List<ProgramsScheduledBean> list = service.viewCourse();
		if (list.isEmpty()) {
			String msg = "There are no Courses";
			mv.addObject("isFirst", 5);
			mv.setViewName("viewCourse");
			mv.addObject("msg", msg);
		} else {
			mv.setViewName("viewCourse");
			mv.addObject("list", list);
		}

		return mv;
	}

	@RequestMapping("/apply")
	public ModelAndView apply(@RequestParam("scheduledProgramId") int id,HttpServletResponse res)
			throws UASException {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ApplicationBean applicant = new ApplicationBean();
		ModelAndView mv = new ModelAndView();
		mv.setViewName("viewCourse");
		mv.addObject("applicant", applicant);
		mv.addObject("scheduledProgramId", id);
		mv.addObject("sample", true);
		mv.addObject("isFirst", 4);
		List<ProgramsScheduledBean> list = service.viewCourse();
		if (list.isEmpty()) {
			String msg = "There are no Courses";
			mv.addObject("msg", msg);
		} else {
			mv.setViewName("viewCourse");
			mv.addObject("list", list);
		}
		return mv;

	}

	@RequestMapping("/applicantSubmit")
	public ModelAndView applicantSubmit(
			@ModelAttribute("applicant") ApplicationBean applicant,
			BindingResult result,HttpServletResponse res) throws UASException {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		try {
			if (!result.hasErrors()) {
				ApplicationBean applicant1 = service.addApplicant(applicant);
				if (applicant1 != null) {
					mv.addObject("flag1", true);
					mv.addObject("msg1",
							"Your application has been registered successfully");
					mv.addObject("msg", "Your applicant Id is: ");

					List<ProgramsScheduledBean> list = service.viewCourse();
					if (list.isEmpty()) {
						String msg = "There are no Courses";
						mv.addObject("msg", msg);
					} else {
						mv.setViewName("viewCourse");
						mv.addObject("list", list);
						mv.addObject("applicant1", applicant1);
					}
				} else {
					mv.addObject("msg", "Failed to Add");
					mv.setViewName("viewCourse");
				}

			} else {
				List<ProgramsScheduledBean> list = service.viewCourse();
				mv = new ModelAndView("viewCourse", "applicant", applicant);
				mv.addObject("list", list);
				mv.addObject("sample", true);
			}

		} catch (Exception e) {
			List<ProgramsScheduledBean> list = service.viewCourse();
			mv.addObject("flag", true);
			mv.addObject("list", list);
			mv.addObject("msg1", "Please enter valid Scheduled program ID!!");
			mv.setViewName("viewCourse");
		}
		return mv;
	}

	@RequestMapping("/checkStatus")
	public ModelAndView checkStatus(HttpServletResponse res) {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
		ModelAndView mv = new ModelAndView();
		ApplicationBean applicant = new ApplicationBean();
		mv.addObject("applicant", applicant);
		mv.addObject("isFirst", 5);
		mv.setViewName("checkStatus");
		return mv;
	}

	@RequestMapping("/displayStatus")
	public ModelAndView displayStatus(
			@ModelAttribute("applicant") ApplicationBean applicant,HttpServletResponse res)
			throws UASException {
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");
			ModelAndView mv = new ModelAndView();
		ApplicationBean applicant2 = new ApplicationBean();
		applicant2 = service.viewStatus(applicant.getApplicationId());
		if (applicant2 != null) {
			mv.setViewName("checkStatus");
			mv.addObject("applicant", applicant2);
			mv.addObject("flag2", true);
		} else {
			String msg = "Enter a Valid Id!!";
			mv.setViewName("checkStatus");
			mv.addObject("msg", msg);
		}
		return mv;
	}

	@RequestMapping(value = "/logout")
	public ModelAndView logout(HttpServletRequest request,
			HttpServletResponse res) {
		
		// System.out.println("logout()");

		HttpSession session = request.getSession(false);
		res.setHeader("Cache-Control", "no-cache");
		res.setHeader("Cache-Control", "no-store");
		res.setDateHeader("Expires", 0);
		res.setHeader("Pragma", "no-cache");

		session.invalidate();
		String msg = "oops! Your Session has been Expired.Please relogin";
		ModelAndView mv = new ModelAndView();
		LoginBean bean = new LoginBean();
		mv.addObject("msg", msg);
		mv.addObject("bean", bean);
		mv.addObject("isFirst", 9);
		mv.setViewName("login");
		return mv;

	}

}
