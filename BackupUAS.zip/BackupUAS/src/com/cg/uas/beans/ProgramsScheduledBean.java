package com.cg.uas.beans;

import java.sql.Date;






import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="programs_scheduled")
public class ProgramsScheduledBean {
  
	@Id
	@Column(name="scheduled_program_id")
	@SequenceGenerator(name="seq1",sequenceName="scheduled_pgm_seq",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq1")
	private int scheduledProgramId;
	

	@Column(name="programName")
	
	private String programName;

	@Column(name="Location")

	private String location;


	@Column(name="start_date")
	private String startDate;
	

	@Column(name="end_date")
	private String endDate;
	

	@Column(name="sessions_per_week ")

	private int sessionPerWeek;
	
	public int getScheduledProgramId() {
		return scheduledProgramId;
	}
	public void setScheduledProgramId(int programId) {
		this.scheduledProgramId = programId;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public int getSessionPerWeek() {
		return sessionPerWeek;
	}
	public void setSessionPerWeek(int sessionPerWeek) {
		this.sessionPerWeek = sessionPerWeek;
	}
	
}