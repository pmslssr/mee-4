package com.cg.bms.service;

import java.util.List;

import com.cg.bms.beans.TransactionBean;
import com.cg.bms.beans.ProductBean;



public interface IProductService {

	
	public ProductBean displayProductDetails(int pcode);
	
	public List<TransactionBean> displayAllTransactionDetails(int pcode);

	

}
