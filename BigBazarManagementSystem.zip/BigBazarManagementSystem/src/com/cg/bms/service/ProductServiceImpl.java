package com.cg.bms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bms.beans.ProductBean;
import com.cg.bms.beans.TransactionBean;
import com.cg.bms.dao.IProductDao;



@Service
public class ProductServiceImpl implements IProductService {

	

	@Autowired
	IProductDao dao;

	
	
	
	public IProductDao getDao() {
		return dao;
	}




	public void setDao(IProductDao dao) {
		this.dao = dao;
	}


	@Override
	public ProductBean displayProductDetails(int pcode) {
		// TODO Auto-generated method stub
		return dao.displayProductDetails(pcode);
	}
	
	
	
	public List<TransactionBean> displayAllTransactionDetails(int pcode) {
		// TODO Auto-generated method stub
		return dao.displayAllTransactionDetails(pcode);
	}
	


	
}
