package com.cg.bms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bms.beans.ProductBean;
import com.cg.bms.beans.TransactionBean;
import com.cg.bms.service.IProductService;




@Controller
public class ProductController {



	@Autowired
	private IProductService service;
	
	
	
	
	public IProductService getService() {
		return service;
	}


	public void setService(IProductService service) {
		this.service = service;
	}


	@RequestMapping("/showIndex")
	public ModelAndView showLogin() {
	
		ProductBean bean = new ProductBean();
		ModelAndView mv = new ModelAndView("index", "product", bean);
		return mv;
	}

	@RequestMapping("/search")
	public ModelAndView search(@ModelAttribute("transac") @Valid ProductBean bean ,BindingResult result) {

		ModelAndView mv = null;
        if(!result.hasErrors())
        {
		ProductBean bean1= service.displayProductDetails(bean.getPcode());
		
		if (bean1 != null) {
			List<TransactionBean> list=service.displayAllTransactionDetails(bean.getPcode());
            if(!list.isEmpty()){
            	mv=new ModelAndView("success");
            	mv.addObject("name", bean1.getPname());
                mv.addObject("id", bean1.getPcode());
                mv.addObject("list",list);
            }
            else
            {
            	mv=new ModelAndView("myError");
            	
                mv.addObject("msg","No Transaction ");
            }
            	
            }
		else{
			mv=new ModelAndView("index");
			mv.addObject("msg","No productId");
		}
        }
     
		return mv;
	}
	
}
