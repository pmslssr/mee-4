package com.cg.bms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bms.beans.TransactionBean;
import com.cg.bms.beans.ProductBean;


@Repository
@Transactional
public class ProductDaoImpl implements IProductDao {


	@PersistenceContext
	private EntityManager entityManager;

	
	
	
	@Override
	public ProductBean displayProductDetails(int pcode) {
		return entityManager.find(ProductBean.class, pcode);
	}

	
	@Override
	public List<TransactionBean> displayAllTransactionDetails(int pcode) 
	{
		TypedQuery<TransactionBean> query = entityManager.createQuery("FROM TransactionBean where pcode=:tpcode", TransactionBean.class);
		query.setParameter("tpcode", pcode);
		return query.getResultList();
	}
	
}
