package com.cg.bms.dao;

import java.util.List;

import com.cg.bms.beans.ProductBean;
import com.cg.bms.beans.TransactionBean;



public interface IProductDao {

	
	public ProductBean displayProductDetails(int pcode);
	
	public List<TransactionBean> displayAllTransactionDetails(int pcode);

}
