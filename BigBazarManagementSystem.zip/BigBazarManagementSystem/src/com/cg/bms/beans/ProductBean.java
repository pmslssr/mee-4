package com.cg.bms.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "product_details")
public class ProductBean {
	
	@Id
	
	private int pcode;
	
	
	private String pname;
	
	
	private int price;
	
	
	private Date pmdate;
	
	
	
	private int quantity;



	public int getPcode() {
		return pcode;
	}



	public void setPcode(int pcode) {
		this.pcode = pcode;
	}



	public String getPname() {
		return pname;
	}



	public void setPname(String pname) {
		this.pname = pname;
	}



	public int getPrice() {
		return price;
	}



	public void setPrice(int price) {
		this.price = price;
	}



	public Date getPmdate() {
		return pmdate;
	}



	public void setPmdate(Date pmdate) {
		this.pmdate = pmdate;
	}



	public int getQuantity() {
		return quantity;
	}



	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	
}
