package com.cg.bms.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "transactions")
public class TransactionBean {
	
	
	@Id

	private int tid;
	
	
	
	private int pcode;
	
	
	
	private Date transdate;
	
	
	private String descr;
	

	private int noofpro;


	public int getTid() {
		return tid;
	}


	public void setTid(int tid) {
		this.tid = tid;
	}


	public int getPcode() {
		return pcode;
	}


	public void setPcode(int pcode) {
		this.pcode = pcode;
	}


	public Date getTransdate() {
		return transdate;
	}


	public void setTransdate(Date transdate) {
		this.transdate = transdate;
	}


	public String getDescr() {
		return descr;
	}


	public void setDescr(String descr) {
		this.descr = descr;
	}


	public int getNoofpro() {
		return noofpro;
	}


	public void setNoofpro(int noofpro) {
		this.noofpro = noofpro;
	}



	

}
