package com.mvc.beans;

import javax.persistence.Id;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

public class AdminBean {

	@Id
	@NotEmpty(message="Please Enter the username")
	@Pattern(regexp = "^[admin]", message = "Username must contain only alphabets")
	private String username;
	 
	@NotEmpty(message="Please Enter the password")
	@Pattern(regexp = "^[admin]", message = "Username must contain only alphabets")
	private String password;




	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
}
