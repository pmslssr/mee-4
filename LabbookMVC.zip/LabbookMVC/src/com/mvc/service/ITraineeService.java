package com.mvc.service;

import java.util.List;

import com.mvc.beans.TraineeBean;

public interface ITraineeService {

	public TraineeBean addTrainee(TraineeBean bean);
	public TraineeBean displayTraineeDetails(int traineeId);
	public List<TraineeBean> displayAllTraineeDetails();
	
	public boolean modifyTrainee(int traineeId, String traineeName, String traineeDomain, String traineeLocation);
	public boolean deleteTrainee(int traineeId);
}
