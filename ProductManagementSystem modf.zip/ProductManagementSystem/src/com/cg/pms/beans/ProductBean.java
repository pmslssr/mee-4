package com.cg.pms.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



import org.hibernate.validator.constraints.NotEmpty;



@Entity
@Table(name = "Product_table")
public class ProductBean {

	@Id
	private int productId;
	
	@NotEmpty(message="Please Enter Donor Name")
	//@Pattern(regexp = "^[a-zA-Z]+$", message = "Username must contain only alphabets")

	
	private String productName;
	
	
	private String productCategory;
	
	
	private String  productQuantity;
	
	
	
	private String productPrice;



	public int getProductId() {
		return productId;
	}



	public void setProductId(int productId) {
		this.productId = productId;
	}



	public String getProductName() {
		return productName;
	}



	public void setProductName(String productName) {
		this.productName = productName;
	}



	public String getProductCategory() {
		return productCategory;
	}



	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}



	public String getProductQuantity() {
		return productQuantity;
	}



	public void setProductQuantity(String productQuantity) {
		this.productQuantity = productQuantity;
	}



	public String getProductPrice() {
		return productPrice;
	}



	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}

	
	
	
	
}
