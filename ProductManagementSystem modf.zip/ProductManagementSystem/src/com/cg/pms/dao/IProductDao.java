package com.cg.pms.dao;

import java.util.List;

import com.cg.pms.beans.ProductBean;

public interface IProductDao {

	public ProductBean addProduct(ProductBean bean);

	public boolean deleteProduct(int productId);
	
	
	public List<ProductBean> displayAllProductDetails();

	
}
