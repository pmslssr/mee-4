package com.cg.pms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.pms.beans.ProductBean;

@Repository
@Transactional
public class ProductDaoImpl implements IProductDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public ProductBean addProduct(ProductBean bean) {
		entityManager.persist(bean);
		entityManager.flush();
		return bean;
	}
	
	
	@Override
	public boolean deleteProduct(int productId) {
		boolean flag= false;
		ProductBean bean = entityManager.find(ProductBean.class,productId);
		if(bean!=null){
			entityManager.remove(bean);
			
		flag = true;
		}
		else{
			flag = false;
		}
		return flag;
	}
	

	
	
	
	
	@Override
	public List<ProductBean> displayAllProductDetails() {
		TypedQuery<ProductBean> query = entityManager.createQuery("FROM ProductBean", ProductBean.class);
		return query.getResultList();
	}

	
}
