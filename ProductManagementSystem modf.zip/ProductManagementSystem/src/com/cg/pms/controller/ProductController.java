package com.cg.pms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.pms.beans.AdminBean;
import com.cg.pms.beans.ProductBean;
import com.cg.pms.service.IProductService;




@Controller
public class ProductController {



	@Autowired
	private IProductService service;
	
	
	public IProductService getService() {
		return service;
	}


	public void setService(IProductService service) {
		this.service = service;
	}


	@RequestMapping("/showIndex")
	public String showHomePage() {
		return "index";
	}


	@RequestMapping("/showLogin")
	public ModelAndView showLogin() {
	
		AdminBean bean = new AdminBean();

		return new ModelAndView("login", "bean", bean);
	}
	
	
	@RequestMapping("/loginCheck")
	public ModelAndView loginCheck(	@ModelAttribute("bean") @Valid AdminBean bean,
			BindingResult result) {
		
		ModelAndView mv = null;
		if (bean.getUsername().equalsIgnoreCase("admin")&&bean.getPassword().equalsIgnoreCase("praneeth")) {
				mv = new ModelAndView("index");
			}
			 
		else{
			mv = new ModelAndView("error");
		}
		
		return mv;
	}

	
	

	
	@RequestMapping("/showAdd")
	public ModelAndView showAdd() {
	
		ProductBean bean = new ProductBean();

		return new ModelAndView("addProduct", "product", bean);
	}
	
	@RequestMapping("/addProduct")
	public ModelAndView addProduct(
			@ModelAttribute("product") @Valid ProductBean bean,
			BindingResult result) {

		ModelAndView mv = null;

		if (!result.hasErrors()) {
			bean = service.addProduct(bean);
			mv = new ModelAndView("addSuccess");
			mv.addObject("productId", bean.getProductId());
			mv.addObject("productName", bean.getProductName());
		} else {
			mv = new ModelAndView("addpProduct", "product", bean);
		}

		return mv;
	}
	
	
	
	
	@RequestMapping("/showDelete")
	public ModelAndView showDelete() {
	
		ProductBean bean = new ProductBean();
		
		ModelAndView mv = new ModelAndView("deleteProduct", "bean", bean);
		mv.addObject("isFirst", "true");
		return mv;
	}
	
	

	@RequestMapping(value = "/deleteProduct", method=RequestMethod.GET)
	public ModelAndView deleteProduct(@RequestParam("tid") int productId) {
		
		
		ModelAndView mv = new ModelAndView();
		
		if (service.deleteProduct(productId)) {
			
			mv.addObject("message", "The product details have been removed.");
			
			mv.setViewName("success");
		} else {
			mv.setViewName("failure");
		}
		
		return mv;
	}
	
	
	
	
	
	
	
	


	@RequestMapping("/retriveAllProduct")
	public ModelAndView showRetrieveAll() {
	

			ModelAndView mv = new ModelAndView();

			List<ProductBean> list = service.displayAllProductDetails();
			if (list.isEmpty()) {
				String msg = "There are no Proudcts";
				mv.setViewName("myError");
				mv.addObject("msg", msg);
			} else {
				mv.setViewName("retrieveAllProduct");
				mv.addObject("list", list);
			}
			return mv;
		}

	
	
	
}
