SQL> create table product1(productcode number(20) primary key,productname varchar(20),productprice number(20),
productmfd date,totalquantity number(20));

Table created.

SQL> insert into product1 values(1,'pen',20,'23-feb-2017',7);

1 row created.

SQL> insert into product1 values(2,'pencil',22,'21-apr-2017',5);

1 row created.

SQL> insert into product1 values(3,'shoe',15,'22-dec-2017',8);

1 row created.

SQL> insert into product1 values(4,'socks',50,'12-dec-2017',6);

1 row created.

SQL> insert into product1 values(5,'bag',250,'12-dec-2016',12);

1 row created.

SQL> select * from product1;

PRODUCTCODE PRODUCTNAME          PRODUCTPRICE PRODUCTMF TOTALQUANTITY
----------- -------------------- ------------ --------- -------------
          1 pen                            20 23-FEB-17             7
          2 pencil                         22 21-APR-17             5
          3 shoe                           15 22-DEC-17             8
          4 socks                          50 12-DEC-17             6
          5 bag                           250 12-DEC-16            12


SQL> create table transaction1(transactionid number(20),productcode number(20),
  2  transactiondate date,description varchar(20),noofitemspurchased number(20),

  3  primary key(transactionid),foreign key(productcode) references product1(prod
uctcode));

Table created.

SQL> select * from transaction1;

TRANSACTIONID PRODUCTCODE TRANSACTI DESCRIPTION          NOOFITEMSPURCHASED
------------- ----------- --------- -------------------- ------------------
            1           1 27-FEB-17 good                                  5
            2           1 27-MAR-17 ok                                    1
            3           2 27-MAY-17 best                                  1
SQL> insert into transaction1 values(01,1,'27-feb-17','good',5);

1 row created.

SQL> insert into transaction values(01,1,'27-mar-17','ok',1);
insert into transaction values(01,1,'27-mar-17','ok',1)
*
ERROR at line 1:
ORA-00001: unique constraint (SYSTEM.SYS_C008321) violated


SQL> insert into transaction1 values(02,1,'27-mar-17','ok',1);

1 row created.

SQL> insert into transaction1 values(03,2,'27-may-17','best',1);

1 row created.
