package com.cg.product.controller;

import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.product.bean.ProductBean;
import com.cg.product.bean.TransactionBean;
import com.cg.product.service.ProductService;

@Controller
public class ProductController {

	@Autowired
	ProductService service;

	public ProductService getService() {
		return service;
	}

	public void setService(ProductService service) {
		this.service = service;
	}

	@RequestMapping("/entry")
	public ModelAndView showentrypage() {
		ProductBean bean = new ProductBean();
		ModelAndView mv = new ModelAndView("entry");
		mv.addObject("bean", bean);
		
		return mv;
	}

	@RequestMapping("/display")
	public ModelAndView showdisplay(
			@ModelAttribute("bean") @Valid ProductBean bean,
			BindingResult result) {
		ModelAndView mv = new ModelAndView();

		ProductBean bean1 = new ProductBean();

		if (!result.hasErrors()) {
			bean1 = service.findProduct(bean.getProductCode());
			List<TransactionBean> list = service.viewtransaction(bean
					.getProductCode());

			if (bean1 != null) {
				if (!list.isEmpty()) {
					mv.setViewName("display");
					mv.addObject("bean", bean1);
					mv.addObject("list", list);
					return mv;
				} else {

					mv.setViewName("entry");
					mv.addObject("msg", "There are no transactions");
					return mv;
				}
			} else {
				mv = new ModelAndView("entry", "bean", bean);
				mv.setViewName("entry");
				mv.addObject("msg", "Product not found");
				return mv;
				
			}

		}

	return mv;
	}

}
