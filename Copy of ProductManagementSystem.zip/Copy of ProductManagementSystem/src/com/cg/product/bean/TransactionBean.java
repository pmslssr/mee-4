package com.cg.product.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="transaction1")
public class TransactionBean {
	
	@Id
	private int transactionId;
	private int productCode;
	private Date transactionDate;
	private String description;
	private int noOfItemsPurchased;
	
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getNoOfItemsPurchased() {
		return noOfItemsPurchased;
	}
	public void setNoOfItemsPurchased(int noOfItemsPurchased) {
		this.noOfItemsPurchased = noOfItemsPurchased;
	}

	
	
	
}
