package com.cg.product.dao;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.product.bean.ProductBean;
import com.cg.product.bean.TransactionBean;

@Repository
@Transactional
public class ProductDaoImpl implements ProductDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	public ProductBean findProduct(int productCode) {
		ProductBean bean=entityManager.find(ProductBean.class, productCode);
		return bean;
	}


	@Override
	public List<TransactionBean> viewtransaction(int productCode) {
		TypedQuery<TransactionBean> query = entityManager.createQuery("from TransactionBean where productCode=?", TransactionBean.class);
		query.setParameter(1, productCode);
		return query.getResultList();
	}
	

}
