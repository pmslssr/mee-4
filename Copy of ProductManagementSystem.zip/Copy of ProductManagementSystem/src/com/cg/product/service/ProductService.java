package com.cg.product.service;

import java.util.List;

import com.cg.product.bean.ProductBean;
import com.cg.product.bean.TransactionBean;

public interface ProductService {
	public ProductBean findProduct(int productCode);
	public List<TransactionBean> viewtransaction(int productCode);
}
