package com.cg.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.product.bean.ProductBean;
import com.cg.product.bean.TransactionBean;
import com.cg.product.dao.ProductDao;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDao dao;
	
	
	public ProductDao getDao() {
		return dao;
	}




	public void setDao(ProductDao dao) {
		this.dao = dao;
	}


	@Override
	public ProductBean findProduct(int productCode) {
		
		return dao.findProduct(productCode);
	}




	@Override
	public List<TransactionBean> viewtransaction(int productCode) {
	
		return dao.viewtransaction(productCode);
	}

}
